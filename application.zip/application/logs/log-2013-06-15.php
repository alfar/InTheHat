<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-06-15 07:34:47 --> Config Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Hooks Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Utf8 Class Initialized
DEBUG - 2013-06-15 07:34:47 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 07:34:47 --> URI Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Router Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Output Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Security Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Input Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 07:34:47 --> Language Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Loader Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Session Class Initialized
DEBUG - 2013-06-15 07:34:47 --> Helper loaded: string_helper
DEBUG - 2013-06-15 07:34:47 --> Database Driver Class Initialized
DEBUG - 2013-06-15 07:34:48 --> A session cookie was not found.
DEBUG - 2013-06-15 07:34:48 --> Session routines successfully run
DEBUG - 2013-06-15 07:34:48 --> Controller Class Initialized
DEBUG - 2013-06-15 07:34:48 --> Helper loaded: url_helper
DEBUG - 2013-06-15 07:34:54 --> Config Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Hooks Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Utf8 Class Initialized
DEBUG - 2013-06-15 07:34:54 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 07:34:54 --> URI Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Router Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Output Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Security Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Input Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 07:34:54 --> Language Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Loader Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Session Class Initialized
DEBUG - 2013-06-15 07:34:54 --> Helper loaded: string_helper
DEBUG - 2013-06-15 07:34:54 --> Database Driver Class Initialized
DEBUG - 2013-06-15 07:34:55 --> Session routines successfully run
DEBUG - 2013-06-15 07:34:55 --> Controller Class Initialized
DEBUG - 2013-06-15 07:34:55 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:13:18 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:18 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:18 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:18 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:18 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:19 --> A session cookie was not found.
DEBUG - 2013-06-15 21:13:19 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:19 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:19 --> Helper loaded: url_helper
ERROR - 2013-06-15 21:13:19 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 21:13:19 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 21:13:31 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:31 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:31 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:31 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:31 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:32 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:32 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:32 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:13:36 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:36 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:36 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:36 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:36 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:36 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:13:37 --> Model Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:46 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:46 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:46 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:46 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:46 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:46 --> Helper loaded: url_helper
ERROR - 2013-06-15 21:13:46 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 21:13:46 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 21:13:57 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:57 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:57 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:57 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:57 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:57 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:57 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:13:59 --> Config Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:13:59 --> URI Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Router Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Output Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Security Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Input Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:13:59 --> Language Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Loader Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Session Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:13:59 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Session routines successfully run
DEBUG - 2013-06-15 21:13:59 --> Controller Class Initialized
DEBUG - 2013-06-15 21:13:59 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:14:00 --> Model Class Initialized
ERROR - 2013-06-15 21:14:00 --> Severity: Notice  --> Undefined index: id C:\Code\php\InTheHat\application\models\user_model.php 11
DEBUG - 2013-06-15 21:14:00 --> Final output sent to browser
DEBUG - 2013-06-15 21:14:00 --> Total execution time: 1.2191
DEBUG - 2013-06-15 21:14:14 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:14 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:14 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:14 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:14 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:14 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:14 --> Helper loaded: url_helper
ERROR - 2013-06-15 21:14:15 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 21:14:15 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 21:14:20 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:20 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:20 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:20 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:14:20 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:20 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:20 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:14:22 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:22 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:22 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:22 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:22 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:22 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:14:23 --> Model Class Initialized
ERROR - 2013-06-15 21:14:23 --> Severity: Notice  --> Undefined offset: 0 C:\Code\php\InTheHat\application\models\user_model.php 11
DEBUG - 2013-06-15 21:14:23 --> Final output sent to browser
DEBUG - 2013-06-15 21:14:23 --> Total execution time: 1.1251
DEBUG - 2013-06-15 21:14:44 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:44 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:44 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:44 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:44 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:44 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:44 --> Helper loaded: url_helper
ERROR - 2013-06-15 21:14:44 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 21:14:44 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 21:14:48 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:48 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:48 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:48 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:14:48 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:48 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:48 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:14:50 --> Config Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:14:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:14:50 --> URI Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Router Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Output Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Security Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Input Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:14:50 --> Language Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Loader Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Session Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:14:50 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Session routines successfully run
DEBUG - 2013-06-15 21:14:50 --> Controller Class Initialized
DEBUG - 2013-06-15 21:14:50 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:14:51 --> Model Class Initialized
DEBUG - 2013-06-15 21:14:51 --> Final output sent to browser
DEBUG - 2013-06-15 21:14:51 --> Total execution time: 0.9731
DEBUG - 2013-06-15 21:16:32 --> Config Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:16:32 --> URI Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Router Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Output Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Security Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Input Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:16:32 --> Language Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Loader Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Session Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:16:32 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Session routines successfully run
DEBUG - 2013-06-15 21:16:32 --> Controller Class Initialized
DEBUG - 2013-06-15 21:16:32 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:16:35 --> Config Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:16:35 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:16:35 --> URI Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Router Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Output Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Security Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Input Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:16:35 --> Language Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Loader Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Session Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:16:35 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Session routines successfully run
DEBUG - 2013-06-15 21:16:35 --> Controller Class Initialized
DEBUG - 2013-06-15 21:16:35 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:16:36 --> Model Class Initialized
DEBUG - 2013-06-15 21:16:36 --> Final output sent to browser
DEBUG - 2013-06-15 21:16:36 --> Total execution time: 1.0251
DEBUG - 2013-06-15 21:30:37 --> Config Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:30:37 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:30:37 --> URI Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Router Class Initialized
DEBUG - 2013-06-15 21:30:37 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:30:37 --> Output Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Security Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Input Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:30:37 --> Language Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Loader Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Session Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:30:37 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:30:37 --> Session routines successfully run
DEBUG - 2013-06-15 21:30:37 --> Controller Class Initialized
DEBUG - 2013-06-15 21:30:37 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:30:37 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:30:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:30:37 --> Final output sent to browser
DEBUG - 2013-06-15 21:30:37 --> Total execution time: 0.0660
DEBUG - 2013-06-15 21:30:54 --> Config Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:30:54 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:30:54 --> URI Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Router Class Initialized
DEBUG - 2013-06-15 21:30:54 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:30:54 --> Output Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Security Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Input Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:30:54 --> Language Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Loader Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Session Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:30:54 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:30:54 --> Session routines successfully run
DEBUG - 2013-06-15 21:30:54 --> Controller Class Initialized
DEBUG - 2013-06-15 21:30:54 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:30:54 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:30:54 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:30:54 --> Final output sent to browser
DEBUG - 2013-06-15 21:30:54 --> Total execution time: 0.0530
DEBUG - 2013-06-15 21:30:55 --> Config Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:30:55 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:30:55 --> URI Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Router Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Output Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Security Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Input Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:30:55 --> Language Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Loader Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Session Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:30:55 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Session routines successfully run
DEBUG - 2013-06-15 21:30:55 --> Controller Class Initialized
DEBUG - 2013-06-15 21:30:55 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:30:58 --> Config Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:30:58 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:30:58 --> URI Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Router Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Output Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Security Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Input Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:30:58 --> Language Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Loader Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Session Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:30:58 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Session routines successfully run
DEBUG - 2013-06-15 21:30:58 --> Controller Class Initialized
DEBUG - 2013-06-15 21:30:58 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:30:59 --> Model Class Initialized
DEBUG - 2013-06-15 21:30:59 --> Final output sent to browser
DEBUG - 2013-06-15 21:30:59 --> Total execution time: 1.2751
DEBUG - 2013-06-15 21:34:10 --> Config Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:34:10 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:34:10 --> URI Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Router Class Initialized
DEBUG - 2013-06-15 21:34:10 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:34:10 --> Output Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Security Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Input Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:34:10 --> Language Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Loader Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Session Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:34:10 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:34:10 --> Session routines successfully run
DEBUG - 2013-06-15 21:34:10 --> Controller Class Initialized
DEBUG - 2013-06-15 21:34:10 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:34:49 --> Config Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:34:49 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:34:49 --> URI Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Router Class Initialized
DEBUG - 2013-06-15 21:34:49 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:34:49 --> Output Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Security Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Input Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:34:49 --> Language Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Loader Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Session Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:34:49 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Session routines successfully run
DEBUG - 2013-06-15 21:34:49 --> Controller Class Initialized
DEBUG - 2013-06-15 21:34:49 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:34:49 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:34:49 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:34:49 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:34:49 --> Final output sent to browser
DEBUG - 2013-06-15 21:34:49 --> Total execution time: 0.0610
DEBUG - 2013-06-15 21:35:03 --> Config Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:35:03 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:35:03 --> URI Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Router Class Initialized
DEBUG - 2013-06-15 21:35:03 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:35:03 --> Output Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Security Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Input Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:35:03 --> Language Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Loader Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Session Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:35:03 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Session routines successfully run
DEBUG - 2013-06-15 21:35:03 --> Controller Class Initialized
DEBUG - 2013-06-15 21:35:03 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:35:03 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:35:03 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:35:03 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:35:03 --> Final output sent to browser
DEBUG - 2013-06-15 21:35:03 --> Total execution time: 0.0640
DEBUG - 2013-06-15 21:38:19 --> Config Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:38:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:38:19 --> URI Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Router Class Initialized
DEBUG - 2013-06-15 21:38:19 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:38:19 --> Output Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Security Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Input Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:38:19 --> Language Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Loader Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Session Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:38:19 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Session routines successfully run
DEBUG - 2013-06-15 21:38:19 --> Controller Class Initialized
DEBUG - 2013-06-15 21:38:19 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:38:19 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:43:42 --> Config Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:43:42 --> URI Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Router Class Initialized
DEBUG - 2013-06-15 21:43:42 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:43:42 --> Output Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Security Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Input Class Initialized
DEBUG - 2013-06-15 21:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:43:42 --> Language Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Config Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:43:54 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:43:54 --> URI Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Router Class Initialized
DEBUG - 2013-06-15 21:43:54 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:43:54 --> Output Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Security Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Input Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:43:54 --> Language Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Loader Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Session Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:43:54 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Session routines successfully run
DEBUG - 2013-06-15 21:43:54 --> Controller Class Initialized
DEBUG - 2013-06-15 21:43:54 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:43:54 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:44:08 --> Config Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:44:08 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:44:08 --> URI Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Router Class Initialized
DEBUG - 2013-06-15 21:44:08 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:44:08 --> Output Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Security Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Input Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:44:08 --> Language Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Loader Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Session Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:44:08 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Session routines successfully run
DEBUG - 2013-06-15 21:44:08 --> Controller Class Initialized
DEBUG - 2013-06-15 21:44:08 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:44:08 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:44:18 --> Config Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:44:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:44:18 --> URI Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Router Class Initialized
DEBUG - 2013-06-15 21:44:18 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:44:18 --> Output Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Security Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Input Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:44:18 --> Language Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Loader Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Session Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:44:18 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Session routines successfully run
DEBUG - 2013-06-15 21:44:18 --> Controller Class Initialized
DEBUG - 2013-06-15 21:44:18 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:44:18 --> File loaded: application/views/templates/header.php
ERROR - 2013-06-15 21:44:18 --> Severity: Notice  --> Undefined variable: userid C:\Code\php\InTheHat\application\views\pages\home.php 7
DEBUG - 2013-06-15 21:44:18 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:44:18 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:44:18 --> Final output sent to browser
DEBUG - 2013-06-15 21:44:18 --> Total execution time: 0.0610
DEBUG - 2013-06-15 21:44:43 --> Config Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:44:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:44:43 --> URI Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Router Class Initialized
DEBUG - 2013-06-15 21:44:43 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:44:43 --> Output Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Security Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Input Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:44:43 --> Language Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Loader Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Session Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:44:43 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Session routines successfully run
DEBUG - 2013-06-15 21:44:43 --> Controller Class Initialized
DEBUG - 2013-06-15 21:44:43 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:44:43 --> File loaded: application/views/templates/header.php
ERROR - 2013-06-15 21:44:43 --> Severity: Notice  --> Undefined variable: userid C:\Code\php\InTheHat\application\views\pages\home.php 7
DEBUG - 2013-06-15 21:44:43 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:44:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:44:43 --> Final output sent to browser
DEBUG - 2013-06-15 21:44:43 --> Total execution time: 0.0740
DEBUG - 2013-06-15 21:44:57 --> Config Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:44:57 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:44:57 --> URI Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Router Class Initialized
DEBUG - 2013-06-15 21:44:57 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:44:57 --> Output Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Security Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Input Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:44:57 --> Language Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Loader Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Session Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:44:57 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Session routines successfully run
DEBUG - 2013-06-15 21:44:57 --> Controller Class Initialized
DEBUG - 2013-06-15 21:44:57 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:44:57 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:44:57 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:44:57 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:44:57 --> Final output sent to browser
DEBUG - 2013-06-15 21:44:57 --> Total execution time: 0.0700
DEBUG - 2013-06-15 21:45:48 --> Config Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:45:48 --> URI Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Router Class Initialized
DEBUG - 2013-06-15 21:45:48 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:45:48 --> Output Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Security Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Input Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:45:48 --> Language Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Loader Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Session Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:45:48 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:45:48 --> Session routines successfully run
DEBUG - 2013-06-15 21:45:48 --> Controller Class Initialized
DEBUG - 2013-06-15 21:45:48 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:45:48 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:45:48 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:45:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:45:48 --> Final output sent to browser
DEBUG - 2013-06-15 21:45:48 --> Total execution time: 0.0610
DEBUG - 2013-06-15 21:45:50 --> Config Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:45:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:45:50 --> URI Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Router Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Output Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Security Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Input Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:45:50 --> Language Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Loader Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Session Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:45:50 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:45:50 --> Session routines successfully run
DEBUG - 2013-06-15 21:45:50 --> Controller Class Initialized
ERROR - 2013-06-15 21:45:50 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 21:46:29 --> Config Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:46:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:46:29 --> URI Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Router Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Output Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Security Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Input Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:46:29 --> Language Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Loader Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Session Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:46:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:46:29 --> Session routines successfully run
DEBUG - 2013-06-15 21:46:29 --> Controller Class Initialized
ERROR - 2013-06-15 21:46:29 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 21:47:10 --> Config Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:47:10 --> URI Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Router Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Output Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Security Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Input Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:47:10 --> Language Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Loader Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Session Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:47:10 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:47:10 --> Session routines successfully run
DEBUG - 2013-06-15 21:47:10 --> Controller Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Config Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:47:30 --> URI Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Router Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Output Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Security Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Input Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:47:30 --> Language Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Loader Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Session Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:47:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:47:30 --> A session cookie was not found.
DEBUG - 2013-06-15 21:47:30 --> Session routines successfully run
DEBUG - 2013-06-15 21:47:30 --> Controller Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:47:30 --> Config Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:47:30 --> URI Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Router Class Initialized
DEBUG - 2013-06-15 21:47:30 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:47:30 --> Output Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Security Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Input Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:47:30 --> Language Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Loader Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Session Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:47:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:47:30 --> A session cookie was not found.
DEBUG - 2013-06-15 21:47:30 --> Session routines successfully run
DEBUG - 2013-06-15 21:47:30 --> Controller Class Initialized
DEBUG - 2013-06-15 21:47:30 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:47:30 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:47:30 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:47:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:47:30 --> Final output sent to browser
DEBUG - 2013-06-15 21:47:30 --> Total execution time: 0.0510
DEBUG - 2013-06-15 21:47:33 --> Config Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:47:33 --> URI Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Router Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Output Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Security Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Input Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:47:33 --> Language Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Loader Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Session Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:47:33 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Session routines successfully run
DEBUG - 2013-06-15 21:47:33 --> Controller Class Initialized
DEBUG - 2013-06-15 21:47:33 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:48:02 --> Config Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:48:02 --> URI Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Router Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Output Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Security Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Input Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:48:02 --> Language Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Loader Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Session Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:48:02 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Session routines successfully run
DEBUG - 2013-06-15 21:48:02 --> Controller Class Initialized
DEBUG - 2013-06-15 21:48:02 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:48:03 --> Model Class Initialized
DEBUG - 2013-06-15 21:48:03 --> Final output sent to browser
DEBUG - 2013-06-15 21:48:03 --> Total execution time: 1.3391
DEBUG - 2013-06-15 21:48:12 --> Config Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:48:12 --> URI Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Router Class Initialized
DEBUG - 2013-06-15 21:48:12 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:48:12 --> Output Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Security Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Input Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:48:12 --> Language Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Loader Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Session Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:48:12 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Session routines successfully run
DEBUG - 2013-06-15 21:48:12 --> Controller Class Initialized
DEBUG - 2013-06-15 21:48:12 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:48:12 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:48:12 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:48:12 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:48:12 --> Final output sent to browser
DEBUG - 2013-06-15 21:48:12 --> Total execution time: 0.0670
DEBUG - 2013-06-15 21:52:06 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:06 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:06 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:52:06 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:06 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:06 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:06 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:06 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:06 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:52:06 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:52:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:52:06 --> Final output sent to browser
DEBUG - 2013-06-15 21:52:06 --> Total execution time: 0.0710
DEBUG - 2013-06-15 21:52:10 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:10 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:10 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:10 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:10 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:52:10 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:10 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:10 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:10 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:10 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:10 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:52:10 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:10 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:10 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:11 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:11 --> A session cookie was not found.
DEBUG - 2013-06-15 21:52:11 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:11 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:11 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:11 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:52:11 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:52:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:52:11 --> Final output sent to browser
DEBUG - 2013-06-15 21:52:11 --> Total execution time: 0.0510
DEBUG - 2013-06-15 21:52:12 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:12 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:12 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:12 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:12 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:12 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:12 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:12 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:12 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:12 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:12 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:12 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:12 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:13 --> Model Class Initialized
DEBUG - 2013-06-15 21:52:13 --> Final output sent to browser
DEBUG - 2013-06-15 21:52:13 --> Total execution time: 0.6400
DEBUG - 2013-06-15 21:52:24 --> Config Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:52:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:52:24 --> URI Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Router Class Initialized
DEBUG - 2013-06-15 21:52:24 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:52:24 --> Output Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Security Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Input Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:52:24 --> Language Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Loader Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Session Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:52:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Session routines successfully run
DEBUG - 2013-06-15 21:52:24 --> Controller Class Initialized
DEBUG - 2013-06-15 21:52:24 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:52:24 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:52:24 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:52:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:52:24 --> Final output sent to browser
DEBUG - 2013-06-15 21:52:24 --> Total execution time: 0.0560
DEBUG - 2013-06-15 21:54:09 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:09 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:09 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:09 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:09 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:54:09 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:09 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:09 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:09 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:09 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:09 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:54:09 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:09 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:09 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:09 --> A session cookie was not found.
DEBUG - 2013-06-15 21:54:09 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:54:09 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:09 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:09 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:09 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:54:09 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:54:09 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:54:09 --> Final output sent to browser
DEBUG - 2013-06-15 21:54:09 --> Total execution time: 0.0560
DEBUG - 2013-06-15 21:54:20 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:20 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:20 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:20 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:54:20 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:20 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:20 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:20 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:20 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:20 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:54:20 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:54:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:54:20 --> Final output sent to browser
DEBUG - 2013-06-15 21:54:20 --> Total execution time: 0.0710
DEBUG - 2013-06-15 21:54:22 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:22 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:22 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:22 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:22 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:22 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:24 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:24 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:24 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:24 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:24 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:26 --> Model Class Initialized
DEBUG - 2013-06-15 21:54:26 --> Final output sent to browser
DEBUG - 2013-06-15 21:54:26 --> Total execution time: 1.2561
DEBUG - 2013-06-15 21:54:37 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:37 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:37 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:37 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:37 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Session garbage collection performed.
DEBUG - 2013-06-15 21:54:37 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:37 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:37 --> Helper loaded: url_helper
ERROR - 2013-06-15 21:54:38 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 21:54:38 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 21:54:41 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:41 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:41 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:41 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:41 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:41 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:43 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:43 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:43 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:43 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:43 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:43 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:45 --> Model Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Config Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Hooks Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Utf8 Class Initialized
DEBUG - 2013-06-15 21:54:45 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 21:54:45 --> URI Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Router Class Initialized
DEBUG - 2013-06-15 21:54:45 --> No URI present. Default controller set.
DEBUG - 2013-06-15 21:54:45 --> Output Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Security Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Input Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 21:54:45 --> Language Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Loader Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Session Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Helper loaded: string_helper
DEBUG - 2013-06-15 21:54:45 --> Database Driver Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Session routines successfully run
DEBUG - 2013-06-15 21:54:45 --> Controller Class Initialized
DEBUG - 2013-06-15 21:54:45 --> Helper loaded: url_helper
DEBUG - 2013-06-15 21:54:45 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 21:54:45 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 21:54:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 21:54:45 --> Final output sent to browser
DEBUG - 2013-06-15 21:54:45 --> Total execution time: 0.0550
DEBUG - 2013-06-15 22:00:38 --> Config Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:00:38 --> URI Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Router Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Output Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Security Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Input Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:00:38 --> Language Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Loader Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Session Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:00:38 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Session routines successfully run
DEBUG - 2013-06-15 22:00:38 --> Controller Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:00:38 --> Config Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:00:38 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:00:38 --> URI Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Router Class Initialized
DEBUG - 2013-06-15 22:00:38 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:00:38 --> Output Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Security Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Input Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:00:38 --> Language Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Loader Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Session Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:00:38 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:00:38 --> A session cookie was not found.
DEBUG - 2013-06-15 22:00:38 --> Session routines successfully run
DEBUG - 2013-06-15 22:00:38 --> Controller Class Initialized
DEBUG - 2013-06-15 22:00:38 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:00:38 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:00:38 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:00:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:00:38 --> Final output sent to browser
DEBUG - 2013-06-15 22:00:38 --> Total execution time: 0.0630
DEBUG - 2013-06-15 22:00:40 --> Config Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:00:40 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:00:40 --> URI Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Router Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Output Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Security Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Input Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:00:40 --> Language Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Loader Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Session Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:00:40 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Session routines successfully run
DEBUG - 2013-06-15 22:00:40 --> Controller Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:00:40 --> Config Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:00:40 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:00:40 --> URI Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Router Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Output Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Security Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Input Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:00:40 --> Language Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Loader Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Session Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:00:40 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Session routines successfully run
DEBUG - 2013-06-15 22:00:40 --> Controller Class Initialized
DEBUG - 2013-06-15 22:00:40 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:00:41 --> Model Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Config Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:00:41 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:00:41 --> URI Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Router Class Initialized
DEBUG - 2013-06-15 22:00:41 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:00:41 --> Output Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Security Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Input Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:00:41 --> Language Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Loader Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Session Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:00:41 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Session routines successfully run
DEBUG - 2013-06-15 22:00:41 --> Controller Class Initialized
DEBUG - 2013-06-15 22:00:41 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:00:41 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:00:41 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:00:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:00:41 --> Final output sent to browser
DEBUG - 2013-06-15 22:00:41 --> Total execution time: 0.0540
DEBUG - 2013-06-15 22:04:46 --> Config Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:04:46 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:04:46 --> URI Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Router Class Initialized
DEBUG - 2013-06-15 22:04:46 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:04:46 --> Output Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Security Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Input Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:04:46 --> Language Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Loader Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Session Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:04:46 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Session routines successfully run
DEBUG - 2013-06-15 22:04:46 --> Controller Class Initialized
DEBUG - 2013-06-15 22:04:46 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:04:46 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:04:46 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:04:47 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:04:47 --> Final output sent to browser
DEBUG - 2013-06-15 22:04:47 --> Total execution time: 0.0660
DEBUG - 2013-06-15 22:04:48 --> Config Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:04:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:04:48 --> URI Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Router Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Output Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Security Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Input Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:04:48 --> Language Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Loader Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Session Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:04:48 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Session routines successfully run
DEBUG - 2013-06-15 22:04:48 --> Controller Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:04:48 --> Config Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:04:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:04:48 --> URI Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Router Class Initialized
DEBUG - 2013-06-15 22:04:48 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:04:48 --> Output Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Security Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Input Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:04:48 --> Language Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Loader Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Session Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:04:48 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:04:48 --> A session cookie was not found.
DEBUG - 2013-06-15 22:04:48 --> Session routines successfully run
DEBUG - 2013-06-15 22:04:48 --> Controller Class Initialized
DEBUG - 2013-06-15 22:04:48 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:04:48 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:04:48 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:04:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:04:48 --> Final output sent to browser
DEBUG - 2013-06-15 22:04:48 --> Total execution time: 0.0510
DEBUG - 2013-06-15 22:04:50 --> Config Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:04:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:04:50 --> URI Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Router Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Output Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Security Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Input Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:04:50 --> Language Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Loader Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Session Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:04:50 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Session routines successfully run
DEBUG - 2013-06-15 22:04:50 --> Controller Class Initialized
DEBUG - 2013-06-15 22:04:50 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:04:53 --> Config Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:04:53 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:04:53 --> URI Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Router Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Output Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Security Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Input Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:04:53 --> Language Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Loader Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Session Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:04:53 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Session routines successfully run
DEBUG - 2013-06-15 22:04:53 --> Controller Class Initialized
DEBUG - 2013-06-15 22:04:53 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:04:54 --> Model Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:18 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:18 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:18 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:18 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:18 --> Helper loaded: url_helper
ERROR - 2013-06-15 22:05:18 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-15 22:05:18 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-15 22:05:23 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:23 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:23 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:23 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:23 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:23 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:23 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:24 --> Model Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:24 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:24 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:05:24 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:24 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:24 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:24 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:24 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:05:24 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:05:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:05:24 --> Final output sent to browser
DEBUG - 2013-06-15 22:05:24 --> Total execution time: 0.0570
DEBUG - 2013-06-15 22:05:28 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:28 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:28 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:28 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:28 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:28 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:28 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:28 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:05:28 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:28 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:28 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:28 --> A session cookie was not found.
DEBUG - 2013-06-15 22:05:28 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:28 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:28 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:28 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:05:28 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:05:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:05:28 --> Final output sent to browser
DEBUG - 2013-06-15 22:05:28 --> Total execution time: 0.0520
DEBUG - 2013-06-15 22:05:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:29 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:29 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:30 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:30 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:30 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:30 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:30 --> Model Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:30 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:30 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:05:30 --> Output Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Security Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Input Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:05:30 --> Language Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Loader Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Session Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:05:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Session routines successfully run
DEBUG - 2013-06-15 22:05:30 --> Controller Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:05:30 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:05:30 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:05:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:05:30 --> Final output sent to browser
DEBUG - 2013-06-15 22:05:30 --> Total execution time: 0.0510
DEBUG - 2013-06-15 22:05:30 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:30 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:30 --> Router Class Initialized
DEBUG - 2013-06-15 22:05:35 --> Config Class Initialized
DEBUG - 2013-06-15 22:05:35 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:05:35 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:05:35 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:05:35 --> URI Class Initialized
DEBUG - 2013-06-15 22:05:35 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:17 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:17 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:17 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:17 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:17 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:17 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:17 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:17 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:06:17 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:17 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:17 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:17 --> A session cookie was not found.
DEBUG - 2013-06-15 22:06:17 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:17 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:17 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:17 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:06:17 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:06:17 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:06:17 --> Final output sent to browser
DEBUG - 2013-06-15 22:06:17 --> Total execution time: 0.0550
DEBUG - 2013-06-15 22:06:18 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:18 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:18 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:18 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:18 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:18 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:18 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:18 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:18 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:18 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:18 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:19 --> Model Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:19 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:19 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:06:19 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:19 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:19 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:19 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:19 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:19 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:06:19 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:06:19 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:06:19 --> Final output sent to browser
DEBUG - 2013-06-15 22:06:19 --> Total execution time: 0.0570
DEBUG - 2013-06-15 22:06:21 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:21 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:21 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:21 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:21 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Session garbage collection performed.
DEBUG - 2013-06-15 22:06:21 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:21 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:21 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:21 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:21 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:21 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:06:21 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:21 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:21 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:21 --> A session cookie was not found.
DEBUG - 2013-06-15 22:06:21 --> Session garbage collection performed.
DEBUG - 2013-06-15 22:06:21 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:21 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:21 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:21 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:06:21 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:06:21 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:06:21 --> Final output sent to browser
DEBUG - 2013-06-15 22:06:21 --> Total execution time: 0.0590
DEBUG - 2013-06-15 22:06:22 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:22 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:22 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:22 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:22 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:22 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:24 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:24 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:24 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:24 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:24 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:25 --> Model Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:25 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:25 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:25 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:06:25 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:25 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:25 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:25 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:25 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:25 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:06:25 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:06:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:06:25 --> Final output sent to browser
DEBUG - 2013-06-15 22:06:25 --> Total execution time: 0.0550
DEBUG - 2013-06-15 22:06:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:29 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:06:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:06:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:06:29 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:06:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:06:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:06:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:06:29 --> A session cookie was not found.
DEBUG - 2013-06-15 22:06:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:06:29 --> Controller Class Initialized
DEBUG - 2013-06-15 22:06:29 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:06:29 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:06:29 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:06:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:06:29 --> Final output sent to browser
DEBUG - 2013-06-15 22:06:29 --> Total execution time: 0.0510
DEBUG - 2013-06-15 22:10:46 --> Config Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:10:46 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:10:46 --> URI Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Router Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Output Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Security Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Input Class Initialized
DEBUG - 2013-06-15 22:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:10:46 --> Language Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Config Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:11:28 --> URI Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Router Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Output Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Security Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Input Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:11:28 --> Language Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Loader Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Session Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:11:28 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Session routines successfully run
DEBUG - 2013-06-15 22:11:28 --> Controller Class Initialized
DEBUG - 2013-06-15 22:11:28 --> Model Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Config Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:11:59 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:11:59 --> URI Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Router Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Output Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Security Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Input Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:11:59 --> Language Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Loader Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Session Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:11:59 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Session routines successfully run
DEBUG - 2013-06-15 22:11:59 --> Controller Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Model Class Initialized
DEBUG - 2013-06-15 22:11:59 --> Final output sent to browser
DEBUG - 2013-06-15 22:11:59 --> Total execution time: 0.0770
DEBUG - 2013-06-15 22:25:24 --> Config Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:25:24 --> URI Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Router Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Output Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Security Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Input Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:25:24 --> Language Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Loader Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Session Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:25:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Session routines successfully run
DEBUG - 2013-06-15 22:25:24 --> Controller Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Model Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:25:24 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:25:24 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:25:24 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:25:24 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:25:24 --> Final output sent to browser
DEBUG - 2013-06-15 22:25:24 --> Total execution time: 0.0910
DEBUG - 2013-06-15 22:26:37 --> Config Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:26:37 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:26:37 --> URI Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Router Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Output Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Security Class Initialized
DEBUG - 2013-06-15 22:26:37 --> Input Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:26:38 --> Language Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Loader Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Session Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:26:38 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Session routines successfully run
DEBUG - 2013-06-15 22:26:38 --> Controller Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Model Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:26:38 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:26:38 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:26:38 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:26:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:26:38 --> Final output sent to browser
DEBUG - 2013-06-15 22:26:38 --> Total execution time: 0.1060
DEBUG - 2013-06-15 22:27:11 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:11 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:11 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:11 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:11 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Model Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:27:11 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:11 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:27:11 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:27:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:27:11 --> Final output sent to browser
DEBUG - 2013-06-15 22:27:11 --> Total execution time: 0.0600
DEBUG - 2013-06-15 22:27:31 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:31 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:31 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:31 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:31 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Model Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:27:31 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:31 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:27:31 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:27:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:27:31 --> Final output sent to browser
DEBUG - 2013-06-15 22:27:31 --> Total execution time: 0.0750
DEBUG - 2013-06-15 22:27:51 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:51 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:51 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:27:51 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:51 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:51 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:51 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:51 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:51 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:27:51 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:27:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:27:51 --> Final output sent to browser
DEBUG - 2013-06-15 22:27:51 --> Total execution time: 0.0620
DEBUG - 2013-06-15 22:27:52 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:52 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:52 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:52 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:52 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:52 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:54 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:54 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:54 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:54 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:54 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:54 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:54 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:55 --> Model Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:27:55 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:27:55 --> URI Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Router Class Initialized
DEBUG - 2013-06-15 22:27:55 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:27:55 --> Output Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Security Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Input Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:27:55 --> Language Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Loader Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Session Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:27:55 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Session routines successfully run
DEBUG - 2013-06-15 22:27:55 --> Controller Class Initialized
DEBUG - 2013-06-15 22:27:55 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:27:55 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:27:55 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:27:55 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:27:55 --> Final output sent to browser
DEBUG - 2013-06-15 22:27:55 --> Total execution time: 0.0550
DEBUG - 2013-06-15 22:27:59 --> Config Class Initialized
DEBUG - 2013-06-15 22:27:59 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:00 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:00 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:00 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:00 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:00 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:00 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:00 --> Helper loaded: form_helper
DEBUG - 2013-06-15 22:28:00 --> Form Validation Class Initialized
DEBUG - 2013-06-15 22:28:00 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:00 --> File loaded: application/views/blog/create.php
DEBUG - 2013-06-15 22:28:00 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:00 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:00 --> Total execution time: 0.0910
DEBUG - 2013-06-15 22:28:22 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:22 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:22 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:22 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:22 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:22 --> Helper loaded: form_helper
DEBUG - 2013-06-15 22:28:22 --> Form Validation Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-06-15 22:28:22 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:22 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:22 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:22 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:22 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:22 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:22 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:22 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:28:22 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:22 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:22 --> Total execution time: 0.0820
DEBUG - 2013-06-15 22:28:26 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:26 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:26 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:28:26 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:26 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:26 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:26 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:26 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:26 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:26 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:28:26 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:26 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:26 --> Total execution time: 0.0590
DEBUG - 2013-06-15 22:28:28 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:28 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:28 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:28 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:28 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:28 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:28 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:28 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:28:28 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:28 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:28 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:28 --> A session cookie was not found.
DEBUG - 2013-06-15 22:28:28 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:28 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:28 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:28 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:28 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:28:28 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:28 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:28 --> Total execution time: 0.0510
DEBUG - 2013-06-15 22:28:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:29 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:29 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:29 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:30 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:30 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:30 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:28:30 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:30 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:30 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:30 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:30 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:30 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-15 22:28:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:30 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:30 --> Total execution time: 0.0570
DEBUG - 2013-06-15 22:28:36 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:36 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:36 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:36 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:36 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:36 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:36 --> Helper loaded: form_helper
DEBUG - 2013-06-15 22:28:36 --> Form Validation Class Initialized
DEBUG - 2013-06-15 22:28:36 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:36 --> File loaded: application/views/blog/create.php
DEBUG - 2013-06-15 22:28:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:36 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:36 --> Total execution time: 0.0620
DEBUG - 2013-06-15 22:28:56 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:56 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:56 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:56 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:56 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:56 --> Helper loaded: form_helper
DEBUG - 2013-06-15 22:28:56 --> Form Validation Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-06-15 22:28:56 --> Config Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:28:56 --> URI Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Router Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Output Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Security Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Input Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:28:56 --> Language Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Loader Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Session Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:28:56 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Session routines successfully run
DEBUG - 2013-06-15 22:28:56 --> Controller Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Model Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:28:56 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:28:56 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:28:56 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 22:28:56 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:28:56 --> Final output sent to browser
DEBUG - 2013-06-15 22:28:56 --> Total execution time: 0.0760
DEBUG - 2013-06-15 22:39:11 --> Config Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:39:11 --> URI Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Router Class Initialized
DEBUG - 2013-06-15 22:39:11 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:39:11 --> Output Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Security Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Input Class Initialized
DEBUG - 2013-06-15 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:39:11 --> Language Class Initialized
ERROR - 2013-06-15 22:39:11 --> 404 Page Not Found --> dashboard/index
DEBUG - 2013-06-15 22:39:29 --> Config Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:39:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:39:29 --> URI Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Router Class Initialized
DEBUG - 2013-06-15 22:39:29 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:39:29 --> Output Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Security Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Input Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:39:29 --> Language Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Loader Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Session Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:39:29 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:39:29 --> Session routines successfully run
DEBUG - 2013-06-15 22:39:29 --> Controller Class Initialized
ERROR - 2013-06-15 22:39:29 --> Severity: Notice  --> Undefined property: Dashboard::$blog_model C:\Code\php\InTheHat\application\controllers\dashboard.php 11
DEBUG - 2013-06-15 22:39:45 --> Config Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:39:45 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:39:45 --> URI Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Router Class Initialized
DEBUG - 2013-06-15 22:39:45 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:39:45 --> Output Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Security Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Input Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:39:45 --> Language Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Loader Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Session Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:39:45 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Session routines successfully run
DEBUG - 2013-06-15 22:39:45 --> Controller Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Model Class Initialized
DEBUG - 2013-06-15 22:39:45 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:39:45 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:40:19 --> Config Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:40:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:40:19 --> URI Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Router Class Initialized
DEBUG - 2013-06-15 22:40:19 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:40:19 --> Output Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Security Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Input Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:40:19 --> Language Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Loader Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Session Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:40:19 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Session routines successfully run
DEBUG - 2013-06-15 22:40:19 --> Controller Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Model Class Initialized
DEBUG - 2013-06-15 22:40:19 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:40:19 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:40:19 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:40:19 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:40:19 --> Final output sent to browser
DEBUG - 2013-06-15 22:40:19 --> Total execution time: 0.0740
DEBUG - 2013-06-15 22:43:45 --> Config Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:43:45 --> URI Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Router Class Initialized
DEBUG - 2013-06-15 22:43:45 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:43:45 --> Output Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Security Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Input Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:43:45 --> Language Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Loader Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Session Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:43:45 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Session routines successfully run
DEBUG - 2013-06-15 22:43:45 --> Controller Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Model Class Initialized
DEBUG - 2013-06-15 22:43:45 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:43:45 --> File loaded: application/views/templates/header.php
ERROR - 2013-06-15 22:43:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Code\php\InTheHat\application\views\dashboard\index.php 2
ERROR - 2013-06-15 22:43:45 --> Severity: Notice  --> Undefined variable: links C:\Code\php\InTheHat\application\views\dashboard\index.php 13
DEBUG - 2013-06-15 22:43:45 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:43:45 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:43:45 --> Final output sent to browser
DEBUG - 2013-06-15 22:43:45 --> Total execution time: 0.0880
DEBUG - 2013-06-15 22:47:43 --> Config Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:47:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:47:43 --> URI Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Router Class Initialized
DEBUG - 2013-06-15 22:47:43 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:47:43 --> Output Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Security Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Input Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:47:43 --> Language Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Loader Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Session Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:47:43 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Session routines successfully run
DEBUG - 2013-06-15 22:47:43 --> Controller Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Model Class Initialized
DEBUG - 2013-06-15 22:47:43 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:47:43 --> File loaded: application/views/templates/header.php
ERROR - 2013-06-15 22:47:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\Code\php\InTheHat\application\views\dashboard\index.php 2
DEBUG - 2013-06-15 22:47:43 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:47:43 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:47:43 --> Final output sent to browser
DEBUG - 2013-06-15 22:47:43 --> Total execution time: 0.0900
DEBUG - 2013-06-15 22:49:34 --> Config Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:49:34 --> URI Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Router Class Initialized
DEBUG - 2013-06-15 22:49:34 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:49:34 --> Output Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Security Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Input Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:49:34 --> Language Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Loader Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Session Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:49:34 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Session routines successfully run
DEBUG - 2013-06-15 22:49:34 --> Controller Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Model Class Initialized
DEBUG - 2013-06-15 22:49:34 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:49:34 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:49:34 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:49:34 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:49:34 --> Final output sent to browser
DEBUG - 2013-06-15 22:49:34 --> Total execution time: 0.0790
DEBUG - 2013-06-15 22:49:40 --> Config Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:49:40 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:49:40 --> URI Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Router Class Initialized
DEBUG - 2013-06-15 22:49:40 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:49:40 --> Output Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Security Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Input Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:49:40 --> Language Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Loader Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Session Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:49:40 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Session garbage collection performed.
DEBUG - 2013-06-15 22:49:40 --> Session routines successfully run
DEBUG - 2013-06-15 22:49:40 --> Controller Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Model Class Initialized
DEBUG - 2013-06-15 22:49:40 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:49:40 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:49:40 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:49:40 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:49:40 --> Final output sent to browser
DEBUG - 2013-06-15 22:49:40 --> Total execution time: 0.0700
DEBUG - 2013-06-15 22:50:04 --> Config Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:50:04 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:50:04 --> URI Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Router Class Initialized
DEBUG - 2013-06-15 22:50:04 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:50:04 --> Output Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Security Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Input Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:50:04 --> Language Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Loader Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Session Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:50:04 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Session routines successfully run
DEBUG - 2013-06-15 22:50:04 --> Controller Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Model Class Initialized
DEBUG - 2013-06-15 22:50:04 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:50:04 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:50:04 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:50:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:50:04 --> Final output sent to browser
DEBUG - 2013-06-15 22:50:04 --> Total execution time: 0.0840
DEBUG - 2013-06-15 22:50:11 --> Config Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:50:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:50:11 --> URI Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Router Class Initialized
DEBUG - 2013-06-15 22:50:11 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:50:11 --> Output Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Security Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Input Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:50:11 --> Language Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Loader Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Session Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:50:11 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Session routines successfully run
DEBUG - 2013-06-15 22:50:11 --> Controller Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Model Class Initialized
DEBUG - 2013-06-15 22:50:11 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:50:11 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:50:11 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:50:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:50:11 --> Final output sent to browser
DEBUG - 2013-06-15 22:50:11 --> Total execution time: 0.0840
DEBUG - 2013-06-15 22:51:36 --> Config Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:51:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:51:36 --> URI Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Router Class Initialized
DEBUG - 2013-06-15 22:51:36 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:51:36 --> Output Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Security Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Input Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:51:36 --> Language Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Loader Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Session Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:51:36 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Session routines successfully run
DEBUG - 2013-06-15 22:51:36 --> Controller Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Model Class Initialized
DEBUG - 2013-06-15 22:51:36 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:51:36 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:51:36 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:51:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:51:36 --> Final output sent to browser
DEBUG - 2013-06-15 22:51:36 --> Total execution time: 0.0670
DEBUG - 2013-06-15 22:52:27 --> Config Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:52:27 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:52:27 --> URI Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Router Class Initialized
DEBUG - 2013-06-15 22:52:27 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:52:27 --> Output Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Security Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Input Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:52:27 --> Language Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Loader Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Session Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:52:27 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Session routines successfully run
DEBUG - 2013-06-15 22:52:27 --> Controller Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Model Class Initialized
DEBUG - 2013-06-15 22:52:27 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:52:27 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:52:27 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:52:27 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:52:27 --> Final output sent to browser
DEBUG - 2013-06-15 22:52:27 --> Total execution time: 0.0750
DEBUG - 2013-06-15 22:52:51 --> Config Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:52:51 --> URI Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Router Class Initialized
DEBUG - 2013-06-15 22:52:51 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:52:51 --> Output Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Security Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Input Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:52:51 --> Language Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Loader Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Session Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:52:51 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Session routines successfully run
DEBUG - 2013-06-15 22:52:51 --> Controller Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Model Class Initialized
DEBUG - 2013-06-15 22:52:51 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:52:51 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:52:51 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:52:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:52:51 --> Final output sent to browser
DEBUG - 2013-06-15 22:52:51 --> Total execution time: 0.0650
DEBUG - 2013-06-15 22:53:04 --> Config Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:53:04 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:53:04 --> URI Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Router Class Initialized
DEBUG - 2013-06-15 22:53:04 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:53:04 --> Output Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Security Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Input Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:53:04 --> Language Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Loader Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Session Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:53:04 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Session routines successfully run
DEBUG - 2013-06-15 22:53:04 --> Controller Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Model Class Initialized
DEBUG - 2013-06-15 22:53:04 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:53:04 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:53:04 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:53:04 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:53:04 --> Final output sent to browser
DEBUG - 2013-06-15 22:53:04 --> Total execution time: 0.0740
DEBUG - 2013-06-15 22:53:31 --> Config Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:53:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:53:31 --> URI Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Router Class Initialized
DEBUG - 2013-06-15 22:53:31 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:53:31 --> Output Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Security Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Input Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:53:31 --> Language Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Loader Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Session Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:53:31 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Session garbage collection performed.
DEBUG - 2013-06-15 22:53:31 --> Session routines successfully run
DEBUG - 2013-06-15 22:53:31 --> Controller Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Model Class Initialized
DEBUG - 2013-06-15 22:53:31 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:53:31 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:53:31 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:53:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:53:31 --> Final output sent to browser
DEBUG - 2013-06-15 22:53:31 --> Total execution time: 0.0700
DEBUG - 2013-06-15 22:53:41 --> Config Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:53:41 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:53:41 --> URI Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Router Class Initialized
DEBUG - 2013-06-15 22:53:41 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:53:41 --> Output Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Security Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Input Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:53:41 --> Language Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Loader Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Session Class Initialized
DEBUG - 2013-06-15 22:53:41 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:53:41 --> Database Driver Class Initialized
ERROR - 2013-06-15 22:53:41 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\Code\php\InTheHat\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-06-15 22:53:42 --> Session routines successfully run
DEBUG - 2013-06-15 22:53:42 --> Controller Class Initialized
DEBUG - 2013-06-15 22:53:42 --> Model Class Initialized
DEBUG - 2013-06-15 22:53:42 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:53:42 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:53:42 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:53:42 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:53:42 --> Final output sent to browser
DEBUG - 2013-06-15 22:53:42 --> Total execution time: 1.1161
DEBUG - 2013-06-15 22:54:19 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:19 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:19 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:54:19 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:19 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:19 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:19 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:19 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:54:19 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:54:23 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:23 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:23 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:23 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:54:23 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:23 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:23 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:23 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:23 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:54:23 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:54:23 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:54:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:54:23 --> Final output sent to browser
DEBUG - 2013-06-15 22:54:23 --> Total execution time: 0.0690
DEBUG - 2013-06-15 22:54:27 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:27 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:27 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:27 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:54:27 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:27 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:27 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:27 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:27 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:54:27 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:54:27 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:54:27 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:54:27 --> Final output sent to browser
DEBUG - 2013-06-15 22:54:27 --> Total execution time: 0.0710
DEBUG - 2013-06-15 22:54:30 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:30 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:30 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:30 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:30 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:54:30 --> Helper loaded: url_helper
ERROR - 2013-06-15 22:54:30 --> 404 Page Not Found --> blogs/and-as-my-facebook-user
DEBUG - 2013-06-15 22:54:51 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:51 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:51 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:51 --> No URI present. Default controller set.
DEBUG - 2013-06-15 22:54:51 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:51 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:51 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:51 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:51 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:54:51 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:54:51 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 22:54:51 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:54:51 --> Final output sent to browser
DEBUG - 2013-06-15 22:54:51 --> Total execution time: 0.0680
DEBUG - 2013-06-15 22:54:53 --> Config Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Hooks Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Utf8 Class Initialized
DEBUG - 2013-06-15 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 22:54:53 --> URI Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Router Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Output Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Security Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Input Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 22:54:53 --> Language Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Loader Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Session Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Helper loaded: string_helper
DEBUG - 2013-06-15 22:54:53 --> Database Driver Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Session routines successfully run
DEBUG - 2013-06-15 22:54:53 --> Controller Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Model Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Pagination Class Initialized
DEBUG - 2013-06-15 22:54:53 --> Helper loaded: url_helper
DEBUG - 2013-06-15 22:54:53 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 22:54:53 --> File loaded: application/views/blog/view.php
DEBUG - 2013-06-15 22:54:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 22:54:53 --> Final output sent to browser
DEBUG - 2013-06-15 22:54:53 --> Total execution time: 0.0740
DEBUG - 2013-06-15 23:02:43 --> Config Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:02:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:02:43 --> URI Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Router Class Initialized
DEBUG - 2013-06-15 23:02:43 --> No URI present. Default controller set.
DEBUG - 2013-06-15 23:02:43 --> Output Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Security Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Input Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:02:43 --> Language Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Loader Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Session Class Initialized
DEBUG - 2013-06-15 23:02:43 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:02:43 --> Database Driver Class Initialized
ERROR - 2013-06-15 23:02:43 --> Severity: Warning  --> mysql_pconnect(): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /hsphere/local/home/wheedk/whee.dk/ith/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2013-06-15 23:02:43 --> Unable to connect to the database
DEBUG - 2013-06-15 23:02:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-06-15 23:07:06 --> Config Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:07:06 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:07:06 --> URI Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Router Class Initialized
DEBUG - 2013-06-15 23:07:06 --> No URI present. Default controller set.
DEBUG - 2013-06-15 23:07:06 --> Output Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Security Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Input Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:07:06 --> Language Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Loader Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Session Class Initialized
DEBUG - 2013-06-15 23:07:06 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:07:24 --> Config Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:07:24 --> URI Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Router Class Initialized
DEBUG - 2013-06-15 23:07:24 --> No URI present. Default controller set.
DEBUG - 2013-06-15 23:07:24 --> Output Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Security Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Input Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:07:24 --> Language Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Loader Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Session Class Initialized
DEBUG - 2013-06-15 23:07:24 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:07:24 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:07:24 --> A session cookie was not found.
DEBUG - 2013-06-15 23:07:25 --> Session routines successfully run
DEBUG - 2013-06-15 23:07:25 --> Controller Class Initialized
DEBUG - 2013-06-15 23:07:25 --> Model Class Initialized
DEBUG - 2013-06-15 23:07:25 --> Helper loaded: url_helper
DEBUG - 2013-06-15 23:07:25 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 23:07:25 --> File loaded: application/views/dashboard/index.php
DEBUG - 2013-06-15 23:07:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 23:07:25 --> Final output sent to browser
DEBUG - 2013-06-15 23:07:25 --> Total execution time: 0.6892
DEBUG - 2013-06-15 23:07:44 --> Config Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:07:44 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:07:44 --> URI Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Router Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Output Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Security Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Input Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:07:44 --> Language Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Loader Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Session Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:07:44 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:07:44 --> Session routines successfully run
DEBUG - 2013-06-15 23:07:44 --> Controller Class Initialized
ERROR - 2013-06-15 23:07:44 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:07:47 --> Config Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:07:47 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:07:47 --> URI Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Router Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Output Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Security Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Input Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:07:47 --> Language Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Loader Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Session Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:07:47 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:07:47 --> Session routines successfully run
DEBUG - 2013-06-15 23:07:47 --> Controller Class Initialized
ERROR - 2013-06-15 23:07:47 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:07:58 --> Config Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:07:58 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:07:58 --> URI Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Router Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Output Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Security Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Input Class Initialized
DEBUG - 2013-06-15 23:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:07:59 --> Language Class Initialized
DEBUG - 2013-06-15 23:07:59 --> Loader Class Initialized
DEBUG - 2013-06-15 23:07:59 --> Session Class Initialized
DEBUG - 2013-06-15 23:07:59 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:07:59 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:07:59 --> Session routines successfully run
DEBUG - 2013-06-15 23:07:59 --> Controller Class Initialized
ERROR - 2013-06-15 23:07:59 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:08:31 --> Config Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:08:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:08:31 --> URI Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Router Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Output Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Security Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Input Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:08:31 --> Language Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Loader Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Session Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:08:31 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:08:31 --> Session routines successfully run
DEBUG - 2013-06-15 23:08:31 --> Controller Class Initialized
ERROR - 2013-06-15 23:08:31 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:08:34 --> Config Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:08:34 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:08:34 --> URI Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Router Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Output Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Security Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Input Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:08:34 --> Language Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Loader Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Session Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:08:34 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:08:34 --> Session routines successfully run
DEBUG - 2013-06-15 23:08:34 --> Controller Class Initialized
ERROR - 2013-06-15 23:08:34 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:08:38 --> Config Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:08:38 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:08:38 --> URI Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Router Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Output Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Security Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Input Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:08:38 --> Language Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Loader Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Session Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:08:38 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Session routines successfully run
DEBUG - 2013-06-15 23:08:38 --> Controller Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Model Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Pagination Class Initialized
DEBUG - 2013-06-15 23:08:38 --> Helper loaded: url_helper
DEBUG - 2013-06-15 23:08:38 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 23:08:38 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 23:08:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 23:08:38 --> Final output sent to browser
DEBUG - 2013-06-15 23:08:38 --> Total execution time: 0.4047
DEBUG - 2013-06-15 23:11:43 --> Config Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:11:43 --> URI Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Router Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Output Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Security Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Input Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:11:43 --> Language Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Loader Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Session Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:11:43 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:11:43 --> Session routines successfully run
DEBUG - 2013-06-15 23:11:43 --> Controller Class Initialized
ERROR - 2013-06-15 23:11:43 --> 404 Page Not Found --> 
DEBUG - 2013-06-15 23:11:46 --> Config Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:11:46 --> URI Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Router Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Output Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Security Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Input Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:11:46 --> Language Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Loader Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Session Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:11:46 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Session routines successfully run
DEBUG - 2013-06-15 23:11:46 --> Controller Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Model Class Initialized
DEBUG - 2013-06-15 23:11:46 --> Pagination Class Initialized
DEBUG - 2013-06-15 23:11:47 --> Helper loaded: url_helper
DEBUG - 2013-06-15 23:11:47 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-15 23:11:47 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-15 23:11:47 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-15 23:11:47 --> Final output sent to browser
DEBUG - 2013-06-15 23:11:47 --> Total execution time: 0.4514
DEBUG - 2013-06-15 23:11:50 --> Config Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:11:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:11:50 --> URI Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Router Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Output Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Security Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Input Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:11:50 --> Language Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Loader Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Session Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:11:50 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Session routines successfully run
DEBUG - 2013-06-15 23:11:50 --> Controller Class Initialized
DEBUG - 2013-06-15 23:11:50 --> Helper loaded: url_helper
ERROR - 2013-06-15 23:11:50 --> Unable to load the requested class: oauth2
DEBUG - 2013-06-15 23:12:11 --> Config Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Hooks Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Utf8 Class Initialized
DEBUG - 2013-06-15 23:12:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-15 23:12:11 --> URI Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Router Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Output Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Security Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Input Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-15 23:12:11 --> Language Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Loader Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Session Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Helper loaded: string_helper
DEBUG - 2013-06-15 23:12:11 --> Database Driver Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Session routines successfully run
DEBUG - 2013-06-15 23:12:11 --> Controller Class Initialized
DEBUG - 2013-06-15 23:12:11 --> Helper loaded: url_helper
ERROR - 2013-06-15 23:12:11 --> Unable to load the requested class: oauth2
