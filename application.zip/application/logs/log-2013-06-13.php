<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-06-13 12:18:36 --> Config Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:18:36 --> URI Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Router Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Output Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Security Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Input Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:18:36 --> Language Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Loader Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Controller Class Initialized
DEBUG - 2013-06-13 12:18:36 --> Helper loaded: url_helper
DEBUG - 2013-06-13 12:20:48 --> Config Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:20:48 --> URI Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Router Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Output Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Security Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Input Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:20:48 --> Language Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Loader Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Controller Class Initialized
DEBUG - 2013-06-13 12:20:48 --> Helper loaded: url_helper
DEBUG - 2013-06-13 12:24:49 --> Config Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:24:49 --> URI Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Router Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Output Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Security Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Input Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:24:49 --> Language Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Loader Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Controller Class Initialized
DEBUG - 2013-06-13 12:24:49 --> Helper loaded: url_helper
DEBUG - 2013-06-13 12:24:51 --> Config Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:24:51 --> URI Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Router Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Output Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Security Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Input Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:24:51 --> Language Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Loader Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Controller Class Initialized
DEBUG - 2013-06-13 12:24:51 --> Helper loaded: url_helper
DEBUG - 2013-06-13 12:27:36 --> Config Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:27:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:27:36 --> URI Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Router Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Output Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Security Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Input Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:27:36 --> Language Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Loader Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Controller Class Initialized
DEBUG - 2013-06-13 12:27:36 --> Helper loaded: url_helper
ERROR - 2013-06-13 12:27:36 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 12:29:08 --> Config Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Hooks Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Utf8 Class Initialized
DEBUG - 2013-06-13 12:29:08 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 12:29:08 --> URI Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Router Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Output Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Security Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Input Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 12:29:08 --> Language Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Loader Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Controller Class Initialized
DEBUG - 2013-06-13 12:29:08 --> Helper loaded: url_helper
ERROR - 2013-06-13 12:29:08 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 20:57:26 --> Config Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Hooks Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Utf8 Class Initialized
DEBUG - 2013-06-13 20:57:26 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 20:57:26 --> URI Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Router Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Output Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Security Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Input Class Initialized
DEBUG - 2013-06-13 20:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 20:57:26 --> Language Class Initialized
DEBUG - 2013-06-13 20:57:27 --> Loader Class Initialized
DEBUG - 2013-06-13 20:57:27 --> Controller Class Initialized
DEBUG - 2013-06-13 20:57:27 --> Helper loaded: url_helper
ERROR - 2013-06-13 20:57:27 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 20:58:59 --> Config Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Hooks Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Utf8 Class Initialized
DEBUG - 2013-06-13 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 20:58:59 --> URI Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Router Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Output Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Security Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Input Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 20:58:59 --> Language Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Loader Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Controller Class Initialized
DEBUG - 2013-06-13 20:58:59 --> Helper loaded: url_helper
ERROR - 2013-06-13 20:58:59 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 21:09:46 --> Config Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:09:46 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:09:46 --> URI Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Router Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Output Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Security Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Input Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:09:46 --> Language Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Loader Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Controller Class Initialized
DEBUG - 2013-06-13 21:09:46 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:09:46 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 21:48:04 --> Config Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:48:04 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:48:04 --> URI Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Router Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Output Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Security Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Input Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:48:04 --> Language Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Loader Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Controller Class Initialized
DEBUG - 2013-06-13 21:48:04 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:48:04 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 21:48:24 --> Config Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:48:24 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:48:24 --> URI Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Router Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Output Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Security Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Input Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:48:24 --> Language Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Loader Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Controller Class Initialized
DEBUG - 2013-06-13 21:48:24 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:48:24 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 21:48:49 --> Config Class Initialized
DEBUG - 2013-06-13 21:48:49 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:48:49 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:48:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:48:50 --> URI Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Router Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Output Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Security Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Input Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:48:50 --> Language Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Loader Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Controller Class Initialized
DEBUG - 2013-06-13 21:48:50 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:48:50 --> Severity: Notice  --> Undefined property: Auth::$oauth2 C:\Code\php\InTheHat\application\controllers\auth.php 9
DEBUG - 2013-06-13 21:49:15 --> Config Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:49:15 --> URI Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Router Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Output Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Security Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Input Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:49:15 --> Language Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Loader Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Controller Class Initialized
DEBUG - 2013-06-13 21:49:15 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:49:15 --> Severity: Notice  --> Undefined property: Auth::$session C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 117
DEBUG - 2013-06-13 21:52:15 --> Config Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:52:15 --> URI Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Router Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Output Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Security Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Input Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:52:15 --> Language Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Loader Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Controller Class Initialized
DEBUG - 2013-06-13 21:52:15 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:52:15 --> Severity: Notice  --> Undefined property: Auth::$session C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 117
DEBUG - 2013-06-13 21:54:45 --> Config Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:54:45 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:54:45 --> URI Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Router Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Output Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Security Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Input Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:54:45 --> Language Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Loader Class Initialized
DEBUG - 2013-06-13 21:54:45 --> Session Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Config Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:56:18 --> URI Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Router Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Output Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Security Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Input Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:56:18 --> Language Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Loader Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Session Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Helper loaded: string_helper
DEBUG - 2013-06-13 21:56:18 --> A session cookie was not found.
DEBUG - 2013-06-13 21:56:18 --> Session routines successfully run
DEBUG - 2013-06-13 21:56:18 --> Controller Class Initialized
DEBUG - 2013-06-13 21:56:18 --> Helper loaded: url_helper
DEBUG - 2013-06-13 21:59:57 --> Config Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Hooks Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Utf8 Class Initialized
DEBUG - 2013-06-13 21:59:57 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 21:59:57 --> URI Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Router Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Output Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Security Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Input Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 21:59:57 --> Language Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Loader Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Session Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Helper loaded: string_helper
DEBUG - 2013-06-13 21:59:57 --> Session routines successfully run
DEBUG - 2013-06-13 21:59:57 --> Controller Class Initialized
DEBUG - 2013-06-13 21:59:57 --> Helper loaded: url_helper
ERROR - 2013-06-13 21:59:57 --> Severity: Notice  --> Undefined variable: client_id C:\Code\php\InTheHat\application\controllers\auth.php 16
ERROR - 2013-06-13 21:59:57 --> Severity: Notice  --> Undefined variable: client_secret C:\Code\php\InTheHat\application\controllers\auth.php 17
DEBUG - 2013-06-13 22:00:04 --> Config Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:00:04 --> URI Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Router Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Output Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Security Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Input Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:00:04 --> Language Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Loader Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Session Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:00:04 --> Session routines successfully run
DEBUG - 2013-06-13 22:00:04 --> Controller Class Initialized
DEBUG - 2013-06-13 22:00:04 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:01:34 --> Config Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:01:34 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:01:34 --> URI Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Router Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Output Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Security Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Input Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:01:34 --> Language Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Loader Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Session Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:01:34 --> Session routines successfully run
DEBUG - 2013-06-13 22:01:34 --> Controller Class Initialized
DEBUG - 2013-06-13 22:01:34 --> Helper loaded: url_helper
ERROR - 2013-06-13 22:01:34 --> Severity: Warning  --> file_get_contents(): Unable to find the wrapper &quot;https&quot; - did you forget to enable it when you configured PHP? C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-13 22:01:34 --> Severity: Warning  --> file_get_contents(https://accounts.google.com/o/oauth2/token): failed to open stream: Invalid argument C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 183
ERROR - 2013-06-13 22:01:34 --> Severity: Warning  --> get_object_vars() expects parameter 1 to be object, null given C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 185
DEBUG - 2013-06-13 22:02:19 --> Config Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:02:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:02:19 --> URI Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Router Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Output Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Security Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Input Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:02:19 --> Language Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Loader Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Session Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:02:19 --> Session routines successfully run
DEBUG - 2013-06-13 22:02:19 --> Controller Class Initialized
DEBUG - 2013-06-13 22:02:19 --> Helper loaded: url_helper
ERROR - 2013-06-13 22:02:19 --> Severity: Notice  --> Undefined variable: client_id C:\Code\php\InTheHat\application\controllers\auth.php 16
ERROR - 2013-06-13 22:02:19 --> Severity: Notice  --> Undefined variable: client_secret C:\Code\php\InTheHat\application\controllers\auth.php 17
DEBUG - 2013-06-13 22:08:20 --> Config Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:08:20 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:08:20 --> URI Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Router Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Output Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Security Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Input Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:08:20 --> Language Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Loader Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Session Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:08:20 --> Session routines successfully run
DEBUG - 2013-06-13 22:08:20 --> Controller Class Initialized
DEBUG - 2013-06-13 22:08:20 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:08:28 --> Config Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:08:28 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:08:28 --> URI Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Router Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Output Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Security Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Input Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:08:28 --> Language Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Loader Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Session Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:08:28 --> Session routines successfully run
DEBUG - 2013-06-13 22:08:28 --> Controller Class Initialized
DEBUG - 2013-06-13 22:08:28 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:08:29 --> Config Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:08:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:08:29 --> URI Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Router Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Output Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Security Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Input Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:08:29 --> Language Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Loader Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Session Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:08:29 --> Session routines successfully run
DEBUG - 2013-06-13 22:08:29 --> Controller Class Initialized
DEBUG - 2013-06-13 22:08:29 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:08:31 --> Config Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:08:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:08:31 --> URI Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Router Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Output Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Security Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Input Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:08:31 --> Language Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Loader Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Session Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:08:31 --> Session routines successfully run
DEBUG - 2013-06-13 22:08:31 --> Controller Class Initialized
DEBUG - 2013-06-13 22:08:31 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:09:43 --> Config Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:09:43 --> URI Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Router Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Output Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Security Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Input Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:09:43 --> Language Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Loader Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Session Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:09:43 --> Session routines successfully run
DEBUG - 2013-06-13 22:09:43 --> Controller Class Initialized
DEBUG - 2013-06-13 22:09:43 --> Helper loaded: url_helper
ERROR - 2013-06-13 22:09:43 --> Severity: Warning  --> file_get_contents(): Unable to find the wrapper &quot;https&quot; - did you forget to enable it when you configured PHP? C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 166
ERROR - 2013-06-13 22:09:43 --> Severity: Warning  --> file_get_contents(https://graph.facebook.com/oauth/access_token?client_id=526948700700414&amp;client_secret=5116be2d1de8a9d1cadf3c07c543f11d&amp;grant_type=authorization_code&amp;code=AQAko0WF9PK6uGoU6otdphEdDDpKVPcWHiiWkrfYnQwHHHe5IaXusQGOA-pXi8_K4evP9keeWjkjveu8lzlBvzvD1RpdPIpHQzn7o4e_AHhtfKnFaMCIU_9hqNtIeRdlMDF3AzWt2pcaVYJn0Ox4q9v1g9A28mYs4B0PpNnehR9j5cGfGmc5ARlHW35S3X3EjiFvomXrFux30Hptbj0BHky_kwrdmcRfDKbh3UjdEBUStPQLVA9VYmnV7vdfMHZ0YVt3LsSDZ8sWQoNdFAtPt12Xyk73LpKHpibUrK9G1ilN4a8TyAo9pqj_GULUov6qUs0&amp;redirect_uri=http%3A%2F%2Flocalhost%3A81%2Fith%2Findex.php%2Fauth%2Fsession%2Ffacebook): failed to open stream: Invalid argument C:\Code\php\InTheHat\application\sparks\oauth2\0.4.0\libraries\Provider.php 166
DEBUG - 2013-06-13 22:12:30 --> Config Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:12:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:12:30 --> URI Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Router Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Output Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Security Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Input Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:12:30 --> Language Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Loader Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Session Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:12:30 --> Session routines successfully run
DEBUG - 2013-06-13 22:12:30 --> Controller Class Initialized
DEBUG - 2013-06-13 22:12:30 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:12:32 --> Final output sent to browser
DEBUG - 2013-06-13 22:12:32 --> Total execution time: 1.6061
DEBUG - 2013-06-13 22:13:52 --> Config Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:13:52 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:13:52 --> URI Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Router Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Output Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Security Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Input Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:13:52 --> Language Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Loader Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Session Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:13:52 --> Session routines successfully run
DEBUG - 2013-06-13 22:13:52 --> Controller Class Initialized
DEBUG - 2013-06-13 22:13:52 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:13:55 --> Config Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:13:55 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:13:55 --> URI Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Router Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Output Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Security Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Input Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:13:55 --> Language Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Loader Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Session Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:13:55 --> Session routines successfully run
DEBUG - 2013-06-13 22:13:55 --> Controller Class Initialized
DEBUG - 2013-06-13 22:13:55 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:13:56 --> Final output sent to browser
DEBUG - 2013-06-13 22:13:56 --> Total execution time: 1.1301
DEBUG - 2013-06-13 22:14:51 --> Config Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:14:51 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:14:51 --> URI Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Router Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Output Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Security Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Input Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:14:51 --> Language Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Loader Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Session Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:14:51 --> Session routines successfully run
DEBUG - 2013-06-13 22:14:51 --> Controller Class Initialized
DEBUG - 2013-06-13 22:14:51 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:14:55 --> Config Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:14:55 --> URI Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Router Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Output Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Security Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Input Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:14:55 --> Language Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Loader Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Session Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:14:55 --> Session routines successfully run
DEBUG - 2013-06-13 22:14:55 --> Controller Class Initialized
DEBUG - 2013-06-13 22:14:55 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:14:59 --> Config Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Hooks Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Utf8 Class Initialized
DEBUG - 2013-06-13 22:14:59 --> UTF-8 Support Enabled
DEBUG - 2013-06-13 22:14:59 --> URI Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Router Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Output Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Security Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Input Class Initialized
DEBUG - 2013-06-13 22:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-13 22:14:59 --> Language Class Initialized
DEBUG - 2013-06-13 22:15:00 --> Loader Class Initialized
DEBUG - 2013-06-13 22:15:00 --> Session Class Initialized
DEBUG - 2013-06-13 22:15:00 --> Helper loaded: string_helper
DEBUG - 2013-06-13 22:15:00 --> Session routines successfully run
DEBUG - 2013-06-13 22:15:00 --> Controller Class Initialized
DEBUG - 2013-06-13 22:15:00 --> Helper loaded: url_helper
DEBUG - 2013-06-13 22:15:01 --> Final output sent to browser
DEBUG - 2013-06-13 22:15:01 --> Total execution time: 1.0801
