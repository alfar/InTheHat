<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-06-11 21:31:53 --> Config Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:31:53 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:31:53 --> URI Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Router Class Initialized
DEBUG - 2013-06-11 21:31:53 --> No URI present. Default controller set.
DEBUG - 2013-06-11 21:31:53 --> Output Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Security Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Input Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:31:53 --> Language Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Loader Class Initialized
DEBUG - 2013-06-11 21:31:53 --> Controller Class Initialized
DEBUG - 2013-06-11 21:31:53 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:31:53 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-11 21:31:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:31:53 --> Final output sent to browser
DEBUG - 2013-06-11 21:31:53 --> Total execution time: 0.0350
DEBUG - 2013-06-11 21:34:20 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:20 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:20 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:20 --> No URI present. Default controller set.
DEBUG - 2013-06-11 21:34:20 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:20 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:20 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:20 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:34:20 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-11 21:34:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:34:20 --> Final output sent to browser
DEBUG - 2013-06-11 21:34:20 --> Total execution time: 0.0420
DEBUG - 2013-06-11 21:34:23 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:23 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:23 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:23 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Model Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:34:23 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:34:23 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:34:23 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:34:23 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:34:23 --> Final output sent to browser
DEBUG - 2013-06-11 21:34:23 --> Total execution time: 0.0600
DEBUG - 2013-06-11 21:34:27 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:27 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:27 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:27 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Model Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:34:27 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:34:27 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:34:27 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:34:27 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:34:27 --> Final output sent to browser
DEBUG - 2013-06-11 21:34:27 --> Total execution time: 0.0750
DEBUG - 2013-06-11 21:34:30 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:30 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:30 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Model Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:34:30 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:34:30 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:34:30 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:34:30 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:34:30 --> Final output sent to browser
DEBUG - 2013-06-11 21:34:30 --> Total execution time: 0.0610
DEBUG - 2013-06-11 21:34:38 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:38 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:38 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:38 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Model Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:34:38 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:34:38 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:34:38 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:34:38 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:34:38 --> Final output sent to browser
DEBUG - 2013-06-11 21:34:38 --> Total execution time: 0.0640
DEBUG - 2013-06-11 21:34:40 --> Config Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:34:40 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:34:40 --> URI Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Router Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Output Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Security Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Input Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:34:40 --> Language Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Loader Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Controller Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Model Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:34:40 --> Helper loaded: url_helper
ERROR - 2013-06-11 21:34:40 --> 404 Page Not Found --> blogs/page
DEBUG - 2013-06-11 21:35:08 --> Config Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:35:08 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:35:08 --> URI Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Router Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Output Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Security Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Input Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:35:08 --> Language Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Loader Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Controller Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Model Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:35:08 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:35:08 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:35:08 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:35:08 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:35:08 --> Final output sent to browser
DEBUG - 2013-06-11 21:35:08 --> Total execution time: 0.0510
DEBUG - 2013-06-11 21:35:12 --> Config Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:35:12 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:35:12 --> URI Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Router Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Output Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Security Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Input Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:35:12 --> Language Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Loader Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Controller Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Model Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:35:12 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:35:12 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:35:12 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:35:12 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:35:12 --> Final output sent to browser
DEBUG - 2013-06-11 21:35:12 --> Total execution time: 0.0630
DEBUG - 2013-06-11 21:35:16 --> Config Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Hooks Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Utf8 Class Initialized
DEBUG - 2013-06-11 21:35:16 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 21:35:16 --> URI Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Router Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Output Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Security Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Input Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 21:35:16 --> Language Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Loader Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Controller Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Model Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Database Driver Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Pagination Class Initialized
DEBUG - 2013-06-11 21:35:16 --> Helper loaded: url_helper
DEBUG - 2013-06-11 21:35:16 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 21:35:16 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 21:35:16 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 21:35:16 --> Final output sent to browser
DEBUG - 2013-06-11 21:35:16 --> Total execution time: 0.0690
DEBUG - 2013-06-11 22:48:29 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:29 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:29 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:29 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:29 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:48:29 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:48:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:48:29 --> Final output sent to browser
DEBUG - 2013-06-11 22:48:29 --> Total execution time: 0.0680
DEBUG - 2013-06-11 22:48:31 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:31 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:31 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:31 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:31 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:31 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:48:31 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:48:31 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:48:31 --> Final output sent to browser
DEBUG - 2013-06-11 22:48:31 --> Total execution time: 0.0630
DEBUG - 2013-06-11 22:48:37 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:37 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:37 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:37 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:37 --> Helper loaded: form_helper
DEBUG - 2013-06-11 22:48:37 --> Form Validation Class Initialized
DEBUG - 2013-06-11 22:48:37 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:48:37 --> File loaded: application/views/blog/create.php
DEBUG - 2013-06-11 22:48:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:48:37 --> Final output sent to browser
DEBUG - 2013-06-11 22:48:37 --> Total execution time: 0.0590
DEBUG - 2013-06-11 22:48:52 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:52 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:52 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:52 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:52 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:53 --> Helper loaded: form_helper
DEBUG - 2013-06-11 22:48:53 --> Form Validation Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-06-11 22:48:53 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:53 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:53 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:53 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:53 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:53 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:48:53 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:48:53 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:48:53 --> Final output sent to browser
DEBUG - 2013-06-11 22:48:53 --> Total execution time: 0.0550
DEBUG - 2013-06-11 22:48:56 --> Config Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:48:56 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:48:56 --> URI Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Router Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Output Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Security Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Input Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:48:56 --> Language Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Loader Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Controller Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Model Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:48:56 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:48:56 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:48:56 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:48:56 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:48:56 --> Final output sent to browser
DEBUG - 2013-06-11 22:48:56 --> Total execution time: 0.0610
DEBUG - 2013-06-11 22:52:37 --> Config Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:52:37 --> URI Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Router Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Output Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Security Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Input Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:52:37 --> Language Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Loader Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Controller Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Model Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:52:37 --> Helper loaded: url_helper
ERROR - 2013-06-11 22:52:37 --> Severity: Warning  --> Missing argument 2 for Blog_model::get_blogs(), called in C:\Code\php\InTheHat\application\controllers\blogs.php on line 46 and defined C:\Code\php\InTheHat\application\models\blog_model.php 12
ERROR - 2013-06-11 22:52:37 --> Severity: Notice  --> Undefined variable: start C:\Code\php\InTheHat\application\models\blog_model.php 14
DEBUG - 2013-06-11 22:52:37 --> Final output sent to browser
DEBUG - 2013-06-11 22:52:37 --> Total execution time: 0.0650
DEBUG - 2013-06-11 22:53:19 --> Config Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:53:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:53:19 --> URI Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Router Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Output Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Security Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Input Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:53:19 --> Language Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Loader Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Controller Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Model Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:53:19 --> Helper loaded: url_helper
ERROR - 2013-06-11 22:53:19 --> Severity: Warning  --> Missing argument 1 for Blogs::json_index() C:\Code\php\InTheHat\application\controllers\blogs.php 44
ERROR - 2013-06-11 22:53:19 --> Severity: Notice  --> Undefined variable: page C:\Code\php\InTheHat\application\controllers\blogs.php 46
DEBUG - 2013-06-11 22:53:19 --> Final output sent to browser
DEBUG - 2013-06-11 22:53:19 --> Total execution time: 0.0670
DEBUG - 2013-06-11 22:53:32 --> Config Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:53:32 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:53:32 --> URI Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Router Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Output Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Security Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Input Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:53:32 --> Language Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Loader Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Controller Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Model Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:53:32 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:53:32 --> Final output sent to browser
DEBUG - 2013-06-11 22:53:32 --> Total execution time: 0.0570
DEBUG - 2013-06-11 22:53:50 --> Config Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:53:50 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:53:50 --> URI Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Router Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Output Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Security Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Input Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:53:50 --> Language Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Loader Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Controller Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Model Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:53:50 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:53:50 --> Final output sent to browser
DEBUG - 2013-06-11 22:53:50 --> Total execution time: 0.0620
DEBUG - 2013-06-11 22:53:58 --> Config Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:53:58 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:53:58 --> URI Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Router Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Output Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Security Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Input Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:53:58 --> Language Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Loader Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Controller Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Model Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:53:58 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:53:58 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:53:58 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:53:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:53:58 --> Final output sent to browser
DEBUG - 2013-06-11 22:53:58 --> Total execution time: 0.0620
DEBUG - 2013-06-11 22:54:01 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:01 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:01 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:01 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:01 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:01 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:01 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:01 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:01 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:01 --> Total execution time: 0.0640
DEBUG - 2013-06-11 22:54:03 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:03 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:03 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:03 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:03 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:03 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:03 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:03 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:03 --> Total execution time: 0.0620
DEBUG - 2013-06-11 22:54:06 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:06 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:06 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:06 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:06 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:06 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:06 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:06 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:06 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:06 --> Total execution time: 0.0610
DEBUG - 2013-06-11 22:54:11 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:11 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:11 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:11 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:11 --> Helper loaded: form_helper
DEBUG - 2013-06-11 22:54:11 --> Form Validation Class Initialized
DEBUG - 2013-06-11 22:54:11 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:11 --> File loaded: application/views/blog/create.php
DEBUG - 2013-06-11 22:54:11 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:11 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:11 --> Total execution time: 0.0570
DEBUG - 2013-06-11 22:54:29 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:29 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:29 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:29 --> Helper loaded: form_helper
DEBUG - 2013-06-11 22:54:29 --> Form Validation Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-06-11 22:54:29 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:29 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:29 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:29 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:29 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:29 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:29 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:29 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:29 --> Total execution time: 0.0640
DEBUG - 2013-06-11 22:54:32 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:32 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:32 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:32 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:32 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:32 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:32 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:32 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:32 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:32 --> Total execution time: 0.0640
DEBUG - 2013-06-11 22:54:36 --> Config Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Hooks Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Utf8 Class Initialized
DEBUG - 2013-06-11 22:54:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-11 22:54:36 --> URI Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Router Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Output Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Security Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Input Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-11 22:54:36 --> Language Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Loader Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Controller Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Model Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Database Driver Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Pagination Class Initialized
DEBUG - 2013-06-11 22:54:36 --> Helper loaded: url_helper
DEBUG - 2013-06-11 22:54:36 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-11 22:54:36 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-11 22:54:36 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-11 22:54:36 --> Final output sent to browser
DEBUG - 2013-06-11 22:54:36 --> Total execution time: 0.0630
