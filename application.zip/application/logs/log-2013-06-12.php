<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-06-12 07:43:36 --> Config Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Hooks Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Utf8 Class Initialized
DEBUG - 2013-06-12 07:43:36 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 07:43:36 --> URI Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Router Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Output Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Security Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Input Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 07:43:36 --> Language Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Loader Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Controller Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Model Class Initialized
DEBUG - 2013-06-12 07:43:36 --> Database Driver Class Initialized
ERROR - 2013-06-12 07:43:36 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\Code\php\InTheHat\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-06-12 07:43:37 --> Pagination Class Initialized
DEBUG - 2013-06-12 07:43:37 --> Helper loaded: url_helper
DEBUG - 2013-06-12 07:43:37 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 07:43:37 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 07:43:37 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 07:43:37 --> Final output sent to browser
DEBUG - 2013-06-12 07:43:37 --> Total execution time: 1.0941
DEBUG - 2013-06-12 07:43:41 --> Config Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Hooks Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Utf8 Class Initialized
DEBUG - 2013-06-12 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 07:43:41 --> URI Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Router Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Output Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Security Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Input Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 07:43:41 --> Language Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Loader Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Controller Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Model Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Database Driver Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Pagination Class Initialized
DEBUG - 2013-06-12 07:43:41 --> Helper loaded: url_helper
DEBUG - 2013-06-12 07:43:41 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 07:43:41 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 07:43:41 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 07:43:41 --> Final output sent to browser
DEBUG - 2013-06-12 07:43:41 --> Total execution time: 0.0630
DEBUG - 2013-06-12 07:43:48 --> Config Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Hooks Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Utf8 Class Initialized
DEBUG - 2013-06-12 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 07:43:48 --> URI Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Router Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Output Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Security Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Input Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 07:43:48 --> Language Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Loader Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Controller Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Model Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Database Driver Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Pagination Class Initialized
DEBUG - 2013-06-12 07:43:48 --> Helper loaded: url_helper
DEBUG - 2013-06-12 07:43:48 --> Helper loaded: form_helper
DEBUG - 2013-06-12 07:43:48 --> Form Validation Class Initialized
DEBUG - 2013-06-12 07:43:48 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 07:43:48 --> File loaded: application/views/blog/create.php
DEBUG - 2013-06-12 07:43:48 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 07:43:48 --> Final output sent to browser
DEBUG - 2013-06-12 07:43:48 --> Total execution time: 0.0610
DEBUG - 2013-06-12 07:44:06 --> Config Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Hooks Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Utf8 Class Initialized
DEBUG - 2013-06-12 07:44:06 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 07:44:06 --> URI Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Router Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Output Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Security Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Input Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 07:44:06 --> Language Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Loader Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Controller Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Model Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Database Driver Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Pagination Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Helper loaded: url_helper
DEBUG - 2013-06-12 07:44:06 --> Helper loaded: form_helper
DEBUG - 2013-06-12 07:44:06 --> Form Validation Class Initialized
DEBUG - 2013-06-12 07:44:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-06-12 07:44:07 --> Config Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Hooks Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Utf8 Class Initialized
DEBUG - 2013-06-12 07:44:07 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 07:44:07 --> URI Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Router Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Output Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Security Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Input Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 07:44:07 --> Language Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Loader Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Controller Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Model Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Database Driver Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Pagination Class Initialized
DEBUG - 2013-06-12 07:44:07 --> Helper loaded: url_helper
DEBUG - 2013-06-12 07:44:07 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 07:44:07 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 07:44:07 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 07:44:07 --> Final output sent to browser
DEBUG - 2013-06-12 07:44:07 --> Total execution time: 0.0520
DEBUG - 2013-06-12 22:38:06 --> Config Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Hooks Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Utf8 Class Initialized
DEBUG - 2013-06-12 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 22:38:06 --> URI Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Router Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Output Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Security Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Input Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 22:38:06 --> Language Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Loader Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Controller Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Model Class Initialized
DEBUG - 2013-06-12 22:38:06 --> Database Driver Class Initialized
ERROR - 2013-06-12 22:38:06 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\Code\php\InTheHat\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-06-12 22:38:07 --> Pagination Class Initialized
DEBUG - 2013-06-12 22:38:07 --> Helper loaded: url_helper
DEBUG - 2013-06-12 22:38:07 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 22:38:07 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 22:38:07 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 22:38:07 --> Final output sent to browser
DEBUG - 2013-06-12 22:38:07 --> Total execution time: 1.1131
DEBUG - 2013-06-12 22:38:10 --> Config Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Hooks Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Utf8 Class Initialized
DEBUG - 2013-06-12 22:38:10 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 22:38:10 --> URI Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Router Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Output Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Security Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Input Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 22:38:10 --> Language Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Loader Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Controller Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Model Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Database Driver Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Pagination Class Initialized
DEBUG - 2013-06-12 22:38:10 --> Helper loaded: url_helper
DEBUG - 2013-06-12 22:38:10 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 22:38:10 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 22:38:10 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 22:38:10 --> Final output sent to browser
DEBUG - 2013-06-12 22:38:10 --> Total execution time: 0.0740
DEBUG - 2013-06-12 22:56:20 --> Config Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Hooks Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Utf8 Class Initialized
DEBUG - 2013-06-12 22:56:20 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 22:56:20 --> URI Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Router Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Output Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Security Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Input Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 22:56:20 --> Language Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Loader Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Controller Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Model Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Database Driver Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Pagination Class Initialized
DEBUG - 2013-06-12 22:56:20 --> Helper loaded: url_helper
DEBUG - 2013-06-12 22:56:20 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 22:56:20 --> File loaded: application/views/blog/index.php
DEBUG - 2013-06-12 22:56:20 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 22:56:20 --> Final output sent to browser
DEBUG - 2013-06-12 22:56:20 --> Total execution time: 0.1110
DEBUG - 2013-06-12 22:56:25 --> Config Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Hooks Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Utf8 Class Initialized
DEBUG - 2013-06-12 22:56:25 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 22:56:25 --> URI Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Router Class Initialized
DEBUG - 2013-06-12 22:56:25 --> No URI present. Default controller set.
DEBUG - 2013-06-12 22:56:25 --> Output Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Security Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Input Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 22:56:25 --> Language Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Loader Class Initialized
DEBUG - 2013-06-12 22:56:25 --> Controller Class Initialized
DEBUG - 2013-06-12 22:56:25 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 22:56:25 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-12 22:56:25 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 22:56:25 --> Final output sent to browser
DEBUG - 2013-06-12 22:56:25 --> Total execution time: 0.0500
DEBUG - 2013-06-12 23:01:11 --> Config Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:01:11 --> URI Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Router Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Output Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Security Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Input Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:01:11 --> Language Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Loader Class Initialized
DEBUG - 2013-06-12 23:01:11 --> Controller Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Config Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:04:44 --> URI Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Router Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Output Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Security Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Input Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:04:44 --> Language Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Loader Class Initialized
DEBUG - 2013-06-12 23:04:44 --> Controller Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Config Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:05:11 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:05:11 --> URI Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Router Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Output Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Security Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Input Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:05:11 --> Language Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Loader Class Initialized
DEBUG - 2013-06-12 23:05:11 --> Controller Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Config Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:05:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:05:43 --> URI Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Router Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Output Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Security Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Input Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:05:43 --> Language Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Loader Class Initialized
DEBUG - 2013-06-12 23:05:43 --> Controller Class Initialized
DEBUG - 2013-06-12 23:06:09 --> Config Class Initialized
DEBUG - 2013-06-12 23:06:09 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:06:09 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:06:09 --> URI Class Initialized
DEBUG - 2013-06-12 23:06:09 --> Router Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Config Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:06:13 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:06:13 --> URI Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Router Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Output Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Security Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Input Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:06:13 --> Language Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Loader Class Initialized
DEBUG - 2013-06-12 23:06:13 --> Controller Class Initialized
DEBUG - 2013-06-12 23:06:19 --> Config Class Initialized
DEBUG - 2013-06-12 23:06:19 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:06:19 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:06:19 --> URI Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Router Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Output Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Security Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Input Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:06:20 --> Language Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Loader Class Initialized
DEBUG - 2013-06-12 23:06:20 --> Controller Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Config Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:06:42 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:06:42 --> URI Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Router Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Output Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Security Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Input Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:06:42 --> Language Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Loader Class Initialized
DEBUG - 2013-06-12 23:06:42 --> Controller Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Config Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:06:45 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:06:45 --> URI Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Router Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Output Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Security Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Input Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:06:45 --> Language Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Loader Class Initialized
DEBUG - 2013-06-12 23:06:45 --> Controller Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Config Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:07:29 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:07:29 --> URI Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Router Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Output Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Security Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Input Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:07:29 --> Language Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Loader Class Initialized
DEBUG - 2013-06-12 23:07:29 --> Controller Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Config Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:08:59 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:08:59 --> URI Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Router Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Output Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Security Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Input Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:08:59 --> Language Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Loader Class Initialized
DEBUG - 2013-06-12 23:08:59 --> Controller Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Config Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:09:07 --> URI Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Router Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Output Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Security Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Input Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:09:07 --> Language Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Loader Class Initialized
DEBUG - 2013-06-12 23:09:07 --> Controller Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Config Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:09:14 --> URI Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Router Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Output Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Security Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Input Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:09:14 --> Language Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Loader Class Initialized
DEBUG - 2013-06-12 23:09:14 --> Controller Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Config Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:09:22 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:09:22 --> URI Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Router Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Output Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Security Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Input Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:09:22 --> Language Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Loader Class Initialized
DEBUG - 2013-06-12 23:09:22 --> Controller Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Config Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:10:02 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:10:02 --> URI Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Router Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Output Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Security Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Input Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:10:02 --> Language Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Loader Class Initialized
DEBUG - 2013-06-12 23:10:02 --> Controller Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Config Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:16:34 --> URI Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Router Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Output Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Security Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Input Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:16:34 --> Language Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Loader Class Initialized
DEBUG - 2013-06-12 23:16:34 --> Controller Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Config Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:17:44 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:17:44 --> URI Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Router Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Output Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Security Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Input Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:17:44 --> Language Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Loader Class Initialized
DEBUG - 2013-06-12 23:17:44 --> Controller Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Config Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:17:58 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:17:58 --> URI Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Router Class Initialized
DEBUG - 2013-06-12 23:17:58 --> No URI present. Default controller set.
DEBUG - 2013-06-12 23:17:58 --> Output Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Security Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Input Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:17:58 --> Language Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Loader Class Initialized
DEBUG - 2013-06-12 23:17:58 --> Controller Class Initialized
DEBUG - 2013-06-12 23:17:58 --> File loaded: application/views/templates/header.php
DEBUG - 2013-06-12 23:17:58 --> File loaded: application/views/pages/home.php
DEBUG - 2013-06-12 23:17:58 --> File loaded: application/views/templates/footer.php
DEBUG - 2013-06-12 23:17:58 --> Final output sent to browser
DEBUG - 2013-06-12 23:17:58 --> Total execution time: 0.0440
DEBUG - 2013-06-12 23:18:02 --> Config Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:18:02 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:18:02 --> URI Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Router Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Output Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Security Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Input Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:18:02 --> Language Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Loader Class Initialized
DEBUG - 2013-06-12 23:18:02 --> Controller Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Config Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:18:30 --> URI Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Router Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Output Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Security Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Input Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:18:30 --> Language Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Loader Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Controller Class Initialized
DEBUG - 2013-06-12 23:18:30 --> Helper loaded: url_helper
DEBUG - 2013-06-12 23:18:43 --> Config Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Hooks Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Utf8 Class Initialized
DEBUG - 2013-06-12 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2013-06-12 23:18:43 --> URI Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Router Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Output Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Security Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Input Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-06-12 23:18:43 --> Language Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Loader Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Controller Class Initialized
DEBUG - 2013-06-12 23:18:43 --> Helper loaded: url_helper
