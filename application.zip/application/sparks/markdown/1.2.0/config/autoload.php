<?php

# Load the markdown helper
$autoload['helper'] = array('markdown');