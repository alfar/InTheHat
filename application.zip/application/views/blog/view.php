<h2><?php echo $blog['title'] ?></h2>
<div id="main">
    <?php echo $blog['text'] ?>
</div>
