		</div>
		<script type="text/javascript" src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
	</body>
</html>